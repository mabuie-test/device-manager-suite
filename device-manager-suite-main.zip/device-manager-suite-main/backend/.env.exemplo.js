PORT=3000
MONGO_URI=mongodb://localhost:27017/devicemgr
JWT_SECRET=change_this_secret
SEED_ADMIN_EMAIL=admin@example.com
SEED_ADMIN_PASS=admin123   ADMIN_REGISTRATION_SECRET=put_a_strong_secret_here
